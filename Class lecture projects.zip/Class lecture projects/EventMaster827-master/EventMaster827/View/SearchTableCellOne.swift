//
//  SearchTableCellOne.swift
//  EventMaster827
//
//  Created by mac on 9/30/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class SearchTableCellOne: UITableViewCell {

    @IBOutlet weak var searchCollectionView: UICollectionView!
    static let identifier = "SearchTableCellOne"
    
}
