//
//  Notification+Name.swift
//  EventMaster827
//
//  Created by mac on 10/4/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation


extension Notification.Name {
    static let bookMarkNotification = Notification.Name("Bookmark")
}
