//
//  ViewController.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
    
    @IBOutlet weak var mainCollectionView: UICollectionView!
    @IBOutlet weak var mainTableView: UITableView!
    
    var facts = [Fact]() {
        didSet {
            DispatchQueue.main.async {
                self.mainTableView.reloadData()
                self.mainCollectionView.reloadData()
            }
        }
    }
    
    var favorites = Set<Fact>()
       

    override func viewDidLoad() {
        super.viewDidLoad()
        setupMain()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        favorites = Set<Fact>(core.load())
        mainTableView.reloadData()
    }


    private func setupMain() {
        //Unowned vs weak - both do NOT increase retain count - unowned is NOT an optional. if you use it the property MUST not be nil or it will crash the app
        
        factService.getFacts { [unowned self] fcts in
            self.facts = fcts
            print("Fact Count: \(fcts.count)")
        }
        
        //MARK: Load From UserDefaults
        guard let isFirstTime = UserDefaults.standard.value(forKey: "isUserFirstTime") as? Bool else { return }
        print("IsUserFirstTime: \(isFirstTime)")
    }
    
    
    @objc func favoriteButtonTapped(sender: UIButton) {
        //checking the status of our button by color
        let isFavorited = sender.tintColor == UIColor.gold
        let fact = facts[sender.tag]
        //running logic, depending on button state
        switch isFavorited {
        case false:
            sender.tintColor = UIColor.gold
            favorites.insert(fact)
            core.save(fact)
        case true:
            sender.tintColor = UIColor.lightGray
            favorites.remove(fact)
            core.delete(fact)
        }
    }
    
    
    
}

//MARK: CollectionView
extension MainViewController: UICollectionViewDataSource {
    
    //number of rows to display
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return facts.count
    }
    
    //renders each row
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MainCollectionCell.identifier, for: indexPath) as! MainCollectionCell
        cell.numberString = "\(indexPath.row)"
        return cell
    }
    
    
    
}

extension MainViewController: UICollectionViewDelegateFlowLayout {
    
    //size of each individual cell
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = view.frame.width / 3.5 //consistent across multiple screen sizes
        let height = collectionView.frame.height
        return CGSize(width: width, height: height)
    }
    
}

//MARK: TableView

extension MainViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return facts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CatTableCell.identifier, for: indexPath) as! CatTableCell
        let fact = facts[indexPath.row]
        cell.fact = fact
        cell.favoriteButton.addTarget(self, action: #selector(favoriteButtonTapped(sender:)), for: .touchUpInside)
        //checking if favorites contains Fact to set button color
        cell.favoriteButton.tintColor = favorites.contains(fact) ? UIColor.gold : UIColor.lightGray
        cell.favoriteButton.tag = indexPath.row
        return cell
    }
    
    
    
}


extension MainViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //will only work IF the constraints are set properly
        return UITableView.automaticDimension // auto size cell - for dynamic cell sizes
    }
    
}
