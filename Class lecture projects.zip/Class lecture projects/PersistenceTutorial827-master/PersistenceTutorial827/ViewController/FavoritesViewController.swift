//
//  FavoritesViewController.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class FavoritesViewController: UIViewController {
    
    @IBOutlet weak var favoriteTableView: UITableView!
    
    
    //Main Thread for UI Changes
    var facts = [Fact]() {
        didSet {
            DispatchQueue.main.async {
                 self.favoriteTableView.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        favoriteTableView.tableFooterView = UIView(frame: .zero)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        facts = core.load()
    }

}

//MARK: TableView

extension FavoritesViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return facts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: FavoriteTableCell.identifier, for: indexPath) as! FavoriteTableCell
        let fact = facts[indexPath.row]
        cell.fact = fact
        return cell
    }
    
    
    
}


extension FavoritesViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        //will only work IF the constraints are set properly
        return UITableView.automaticDimension // auto size cell - for dynamic cell sizes
    }
    
}
