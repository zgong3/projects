//
//  FavoriteTableCell.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class FavoriteTableCell: UITableViewCell {

    @IBOutlet weak var favoritesMainLabel: UILabel!
    @IBOutlet weak var favoritesSubLabel: UILabel!
    
    
    static let identifier = "FavoriteTableCell"
    
    var fact: Fact! {
        didSet {
            favoritesMainLabel.text = fact.information
            favoritesSubLabel.text = "Upvotes: \(fact.upvotes)"
        }
    }

}
