//
//  CatTableCell.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class CatTableCell: UITableViewCell {

    @IBOutlet weak var catMainLabel: UILabel!
    @IBOutlet weak var catSubLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    
    var fact: Fact! {
        didSet {
            catMainLabel.text = fact.information
            catSubLabel.text = "Upvotes: \(fact.upvotes)"
        }
    }

    static let identifier = "CatTableCell"
    
    override func layoutSubviews() {
        super.layoutSubviews()
        let image = #imageLiteral(resourceName: "star").withRenderingMode(.alwaysTemplate)
        favoriteButton.setImage(image, for: .normal)
    }
}
