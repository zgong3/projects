//
//  AppDelegate.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        return true
    }


    func applicationWillTerminate(_ application: UIApplication) {
        //MARK: Save To UserDefaults
        UserDefaults.standard.set(false, forKey: "isUserFirstTime")
    }


}

