//
//  CoreManager.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation
import CoreData

let core = CoreManager.shared

final class CoreManager {
    
    
    static let shared = CoreManager()
    private init() {}
    
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    lazy var persistentContainer: NSPersistentContainer = {
        
        var container = NSPersistentContainer(name: "PT")
        
        container.loadPersistentStores(completionHandler: { (storeDescrip, err) in
            if let error = err {
                fatalError(error.localizedDescription)
            }
        })
        
        return container
    }()
    
    
    //MARK: Save
    func save(_ fact: Fact) {
        
        let entity = NSEntityDescription.entity(forEntityName: "CoreFact", in: context)!
        let core = CoreFact(entity: entity, insertInto: context)
        
        //KVC - Key Value Coding - access object property by String
        core.setValue(fact.id, forKey: "id")
        core.setValue(fact.information, forKey: "info")
        core.setValue(fact.upvotes, forKey: "upvotes")
        
        print("Saved Fact To Core: \(fact.id)")
        saveContext()
        
    }

    //MARK: Delete
    func delete(_ fact: Fact) {
        
        let fetchRequest = NSFetchRequest<CoreFact>(entityName: "CoreFact")
        let predicate = NSPredicate(format: "id==%@", fact.id)
        fetchRequest.predicate = predicate
        
        var factResult = [CoreFact]()
        
        do {
            factResult = try context.fetch(fetchRequest)
            
            guard let core = factResult.first else { return }
            context.delete(core)
            print("Deleted Fact From Core: \(fact.id)")
            
        } catch {
            print("Couldn't Fetch Fact: \(error.localizedDescription)")
        }
        
        saveContext()
    }
    
    //MARK: Load
    func load() -> [Fact] {
        
        let fetchRequest = NSFetchRequest<CoreFact>(entityName: "CoreFact")
        
        var facts = [Fact]()
        
        do {
            let coreFacts = try context.fetch(fetchRequest)
            for core in coreFacts {
                facts.append(Fact(from: core))
            }
            
        } catch {
            print("Couldn't Fetch Fact: \(error.localizedDescription)")
        }
        
        return facts
    }
    
    
    //MARK: Helpers
    
    private func saveContext() {
        do {
            try context.save()
        } catch {
            fatalError(error.localizedDescription)
        }
    }
    
}
