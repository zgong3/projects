//
//  FactService.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation

let factService = FactService.shared
typealias FactHandler = ([Fact]) -> Void //a nickname for any type

final class FactService {
    
    
    static let shared = FactService()
    private init() {}
    
    //lazy - late init - only intialized once it is called
    lazy var session: URLSession  = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 10 //time out for request - 10 seconds
        return URLSession(configuration: config)
    }()
    
    
    func getFacts(completion: @escaping FactHandler) {
        
        guard let url = FactAPI().getUrl else {
            completion([])
            return
        }
        
        //API Request
        //Data task completion block is async
        session.dataTask(with: url) { (dat, _, err) in
            
            if let error = err {
                completion([])
                print("Bad Data Task: \(error.localizedDescription)")
                return // exit scope
            }
            
            if let data = dat {
                
                do {
                    let factResponse = try JSONDecoder().decode(FactResponse.self, from: data) //Decodable - does mapping for us
                    completion(factResponse.all)
                } catch {
                    completion([])
                    print("Couldn't Decode Fact: \(error.localizedDescription)")
                    return // exit scope
                }
            }
        }.resume()
    }
    
    
}
