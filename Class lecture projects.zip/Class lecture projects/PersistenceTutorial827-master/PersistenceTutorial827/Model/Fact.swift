//
//  Fact.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation

struct FactResponse: Decodable {
    let all: [Fact]
}

class Fact: Decodable {
    
    let id: String
    let information: String
    let type: String
    let upvotes: Int
    
    //MARK: CodingKey - allows custom naming conventions for decoding JSON keys
    private enum CodingKeys: String, CodingKey {
        case id = "_id"
        case information = "text"
        case type
        case upvotes
    }
    
    init(from core: CoreFact) {
        self.id = core.id!
        self.information = core.info!
        self.type = "cat"
        self.upvotes = Int(core.upvotes)
    }
    
}

extension Fact: Hashable {
    
    static func == (lhs: Fact, rhs: Fact) -> Bool {
        return lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
}
