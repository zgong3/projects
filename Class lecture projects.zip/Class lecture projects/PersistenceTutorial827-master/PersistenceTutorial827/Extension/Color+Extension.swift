//
//  Color+Extension.swift
//  PersistenceTutorial827
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

extension UIColor {
    
    //rgb(238,232,170)
    static let gold = UIColor(red: 238/255, green: 232/255, blue: 170/255, alpha: 1)
    
    
    
}
