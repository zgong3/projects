//
//  Notification+Name.swift
//  ItunesApp827
//
//  Created by mac on 9/10/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation


extension Notification.Name {
    static let AlbumNotification = Notification.Name("Albums")
}
