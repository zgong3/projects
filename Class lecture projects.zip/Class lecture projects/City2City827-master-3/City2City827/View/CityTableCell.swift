//
//  CityTableCell.swift
//  City2City827
//
//  Created by mac on 9/4/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class CityTableCell: UITableViewCell {

    @IBOutlet weak var cityMainLabel: UILabel!
    @IBOutlet weak var citySubLabel: UILabel!
    
    
}
