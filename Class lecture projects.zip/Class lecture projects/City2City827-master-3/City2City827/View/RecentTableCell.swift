//
//  RecentTableCell.swift
//  City2City827
//
//  Created by mac on 9/5/19.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class RecentTableCell: UITableViewCell {

    @IBOutlet weak var recentMainLabel: UILabel!
    @IBOutlet weak var recentSubLabel: UILabel!
    
}
