//
//  ItunesService.h
//  ItunesObjC729
//
//  Created by mac on 9/10/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Album.h"
@class Track;

NS_ASSUME_NONNULL_BEGIN

@interface ItunesService : NSObject

+(instancetype)sharedInstance;


-(void)getAlbumsFor:(NSString*) search completion:(void (^)(NSMutableArray<Album*>*albums)) complete;
//func getAlbumsFor(search: String, completion: @escaping ([Album]) -> Void)

-(void)getTracksFor:(Album*) album completion:(void (^) (NSMutableArray<Track*>*tracks)) completion;

@end

NS_ASSUME_NONNULL_END
