//
//  ItunesService.m
//  ItunesObjC729
//
//  Created by mac on 9/10/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "ItunesService.h"
#import "ItunesObjC729-Swift.h" //use swift functions/properties

@implementation ItunesService

//Obj-C Singleton
+ (instancetype)sharedInstance {
    
    static ItunesService* shared;
    static dispatch_once_t once; //primitive, token to only run one time
    
    dispatch_once(&once, ^{
        //this block will only be ran once
        shared = [ItunesService new];
    });
    
    return shared; 
}

- (void)getAlbumsFor:(NSString* )search completion:(void (^)(NSMutableArray<Album *> * albms))complete {
    
    //https://itunes.apple.com/search?term=michael+jackson&entity=album
    NSString *endpoint = [NSString stringWithFormat:@"https://itunes.apple.com/search?term=%@&entity=album", search];
    NSURL *url = [NSURL URLWithString:endpoint];
    
    [[NSURLSession.sharedSession dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSDictionary * jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
        
        NSArray * albumResults = [jsonResponse objectForKey:@"results"];
        
        NSMutableArray * albums = [NSMutableArray new];
        
        for (NSDictionary * dict in albumResults) {
            Album *album = [[Album new] initWithDict:dict];
            [albums addObject:album];
        };
        
        complete(albums);
        
    }] resume];
}


- (void)getTracksFor:(Album *)album completion:(void (^)(NSMutableArray<Track *> * trks))completion {
    
    //https://itunes.apple.com/lookup?id=1437591818&entity=song - Songs
    NSString *endpoint = [NSString stringWithFormat:@"https://itunes.apple.com/lookup?id=%@&entity=song", album.collectionId];
    NSURL * url = [NSURL URLWithString:endpoint];
    
    
    [[NSURLSession.sharedSession dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (data) {
            
            NSDictionary * jsonResponse = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
            NSArray * jsonResults = [jsonResponse objectForKey:@"results"];
            
            NSMutableArray * tracks = [NSMutableArray new];
            
            for (NSDictionary * dict in jsonResults) {
                Track * trk = [[Track alloc] initFrom:dict];
                if (trk) {
                    [tracks addObject:trk];
                }
            }
            
            completion(tracks);
            
        }
    }] resume];
    
}

@end
