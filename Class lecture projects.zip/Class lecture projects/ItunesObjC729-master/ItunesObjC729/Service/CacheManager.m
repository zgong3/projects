//
//  CacheManager.m
//  ItunesObjC729
//
//  Created by mac on 9/10/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "CacheManager.h"

@implementation CacheManager

+(id)sharedInstance {
    
    static CacheManager* shared;
    static dispatch_once_t once;
    
    dispatch_once(&once, ^{
        shared = [CacheManager new];
    });
    
    return shared;
}

- (void)downloadFrom:(NSString *)endpoint completion:(void (^)(NSData * _Nonnull))complete {
    
    NSData * data = [self.cache objectForKey:endpoint];
    
    if (data) {
        complete(data);
        return;
    }
    
    NSURL *url = [NSURL URLWithString:endpoint];
    
    [[NSURLSession.sharedSession dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        [self.cache setObject:data forKey:endpoint];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            complete(data);
        });
        
    }] resume];
    
    
}
@end
