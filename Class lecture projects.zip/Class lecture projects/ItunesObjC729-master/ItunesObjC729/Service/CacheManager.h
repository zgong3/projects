//
//  CacheManager.h
//  ItunesObjC729
//
//  Created by mac on 9/10/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CacheManager : NSObject

@property (strong, nonatomic) NSCache * cache;
+(id)sharedInstance;
-(void)downloadFrom:(NSString*) endpoint completion:(void (^)(NSData*data)) complete;


@end

NS_ASSUME_NONNULL_END
