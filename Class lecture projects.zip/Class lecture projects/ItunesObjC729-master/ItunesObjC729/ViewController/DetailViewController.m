//
//  DetailViewController.m
//  ItunesObjC729
//
//  Created by mac on 9/12/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "DetailViewController.h"
#import "TrackTableCellOne.h"
#import "TrackTableCellTwo.h"

@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UITableView *detailTableView;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupDetail];
}


//MARK: Setup Detail
-(void)setupDetail {
    [NSNotificationCenter.defaultCenter addObserverForName:@"Album" object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification * _Nonnull note) {
        [self.detailTableView reloadData];
    }];
}

//MARK: TableView

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(nonnull UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return (section == 0) ? 1 : self.viewModel.tracks.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        TrackTableCellOne* cell = [tableView dequeueReusableCellWithIdentifier: @"TrackTableCellOne" forIndexPath: indexPath];
        [cell configure:self.currentAlbum];
        return cell;
    } else {
        TrackTableCellTwo*cell = [tableView dequeueReusableCellWithIdentifier:@"TrackTableCellTwo" forIndexPath:indexPath];
        Track * track = self.viewModel.tracks[indexPath.row];
        [cell configureTrack:track];
        return cell;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return (indexPath.section == 0) ? 140 : 70;
}






@end
