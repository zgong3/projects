//
//  DetailViewController.h
//  ItunesObjC729
//
//  Created by mac on 9/12/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewModel.h"
#import "Album.h"

NS_ASSUME_NONNULL_BEGIN

@interface DetailViewController : UIViewController<UITableViewDelegate, UITableViewDataSource>

@property (strong, nonatomic) ViewModel * viewModel;
@property (strong, nonatomic) Album* currentAlbum;
@end

NS_ASSUME_NONNULL_END
