//
//  MainViewController.m
//  ItunesObjC729
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "MainViewController.h"
#import "MainTableCell.h"
#import "ViewModel.h"
#import "DetailViewController.h"

@interface MainViewController ()

//weak - reference type, non-atomic - property is NOT thread safe but is faster
@property (weak, nonatomic) IBOutlet UITableView *mainTableView; // .m interface is similar to private in Swift
@property (strong, nonatomic) ViewModel* viewModel; //declaring a property, NOT intializing it
@property (strong, nonatomic) UISearchController * searchController;
@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad]; //bracket notation - space delimiter - [object functionName];
    [self setupMain];
    
    //NSArray * numberArr = [[NSArray alloc] initWithObjects:@1, @2, nil];
    //NSLog(@"%ld", numberArr.count);
}


-(void)setupMain {
    [self setDefinesPresentationContext:YES];
    //i-var - the underlying value of a proprety - skips getters and setters and access direclty
    //self.viewModel = [[ViewModel alloc] init]; // initializes a property
    self.viewModel = [ViewModel new]; //same as alloc init
    self.viewModel.delegate = self;
    [self.viewModel getFrom:@"lil+wayne"];
    
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
    self.searchController.searchBar.delegate = self;
    self.navigationItem.searchController = self.searchController;
    self.navigationItem.hidesSearchBarWhenScrolling = NO;
    self.navigationItem.searchController.dimsBackgroundDuringPresentation = NO;
 
}

//MARK: SearchBarDelegate
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    NSString * searchText = searchBar.text;
    NSString * sanitizedSearch = [searchText stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLHostAllowedCharacterSet];
    
    [self.viewModel getFrom:sanitizedSearch];
}

//MARK: ViewModelDelegate
- (void)updateView {
    //GCD - go to main thread
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.mainTableView reloadData];
    });
}

//MARK: TableView

//Functions - "-" means the function belongs to an instance - return type is next - asterisks signify a pointer in memory (must set an asteriks after type, when naming object

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //first state what type the property is - there is NO inference
    MainTableCell *cell = [tableView dequeueReusableCellWithIdentifier:[MainTableCell identifier] forIndexPath:indexPath];
    Album *album = self.viewModel.albums[indexPath.row];
    [cell configureMainWith:album];
    return cell;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.viewModel.albums.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated: YES];
    
    Album *album = self.viewModel.albums[indexPath.row];
    
    DetailViewController * detailVC = [self.storyboard instantiateViewControllerWithIdentifier:@"DetailViewController"];
    [self.viewModel getTracksFor:album];
    detailVC.currentAlbum = album;
    detailVC.viewModel = self.viewModel;
    [self.navigationController pushViewController:detailVC animated:YES];
}

@end
