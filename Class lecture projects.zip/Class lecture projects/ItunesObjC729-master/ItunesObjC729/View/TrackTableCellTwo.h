//
//  TrackTableCellTwo.h
//  ItunesObjC729
//
//  Created by mac on 9/12/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Track;

NS_ASSUME_NONNULL_BEGIN

@interface TrackTableCellTwo : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *trackNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *trackDurationLabel;
@property (weak, nonatomic) IBOutlet UILabel *trackPriceLabel;


-(void)configureTrack:(Track*) track;


@end

NS_ASSUME_NONNULL_END
