//
//  TrackTableCellTwo.m
//  ItunesObjC729
//
//  Created by mac on 9/12/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "TrackTableCellTwo.h"
#import "ItunesObjC729-Swift.h"

@implementation TrackTableCellTwo

- (void)configureTrack:(Track *)track {
    
    self.trackNameLabel.text = track.trackName;
    self.trackPriceLabel.text = [NSString stringWithFormat:@"$%.2f", track.trackPrice];
    self.trackDurationLabel.text = [NSString stringWithFormat:@"%ld", track.trackTimeMillis];
}

@end
