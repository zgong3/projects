//
//  MainTableCell.h
//  ItunesObjC729
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Album.h"
NS_ASSUME_NONNULL_BEGIN

@interface MainTableCell : UITableViewCell

//"+" signifies function belongs to the class NOT an instance
+(NSString*)identifier;

@property (weak, nonatomic) IBOutlet UIImageView *mainImage;
@property (weak, nonatomic) IBOutlet UILabel *mainLabel;
@property (weak, nonatomic) IBOutlet UILabel *mainSubLabel;

-(void)configureMainWith:(Album*) album; //signature for function

@end

NS_ASSUME_NONNULL_END
