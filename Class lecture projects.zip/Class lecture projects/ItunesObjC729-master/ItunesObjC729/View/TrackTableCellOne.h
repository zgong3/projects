//
//  TrackTableCellOne.h
//  ItunesObjC729
//
//  Created by mac on 9/12/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Album.h"

NS_ASSUME_NONNULL_BEGIN

@interface TrackTableCellOne : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *trackAlbumImage;
@property (weak, nonatomic) IBOutlet UILabel *trackAlbumName;
@property (weak, nonatomic) IBOutlet UILabel *trackAlbumArtist;

-(void)configure:(Album*) album;
@end

NS_ASSUME_NONNULL_END
