//
//  TrackTableCellOne.m
//  ItunesObjC729
//
//  Created by mac on 9/12/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "TrackTableCellOne.h"
#import "CacheManager.h"

@implementation TrackTableCellOne


- (void)configure:(Album *)album {
    self.trackAlbumName.text = album.collectionName;
    self.trackAlbumArtist.text = album.artistName;
    
    [CacheManager.sharedInstance downloadFrom:album.imageUrl completion:^(NSData * _Nonnull data) {
        self.trackAlbumImage.image = [UIImage imageWithData:data];
    }];
    
}


@end
