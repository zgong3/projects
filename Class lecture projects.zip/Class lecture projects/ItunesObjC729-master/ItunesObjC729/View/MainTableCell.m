//
//  MainTableCell.m
//  ItunesObjC729
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "MainTableCell.h"
#import "CacheManager.h"

@implementation MainTableCell

+(NSString*)identifier {
    return @"MainTableCell";
}

- (void)configureMainWith:(Album *)album {
    
    self.mainLabel.text = album.collectionName;
    self.mainSubLabel.text = album.artistName;
    
    [CacheManager.sharedInstance downloadFrom:album.imageUrl completion:^(NSData * _Nonnull data) {
        __weak MainTableCell * weakSelf = self; //weak reference self
        weakSelf.mainImage.image = [UIImage imageWithData:data];
    }];
}

@end
