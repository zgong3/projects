//
//  Album.m
//  ItunesObjC729
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "Album.h"

@implementation Album


- (id)initWithDict:(NSDictionary *)dict {
    
    if (self == [super init]) {
        
        NSString * artistName = [dict objectForKey:@"artistName"];
        NSNumber * uid = [dict objectForKey:@"collectionId"];
        NSString * name = [dict objectForKey:@"collectionName"];
        double price = [[dict objectForKey:@"collectionPrice"] doubleValue];
        NSString * url = [dict objectForKey:@"collectionViewUrl"];
        NSString *image = [dict objectForKey:@"artworkUrl100"];
        
        self.artistName = artistName;
        self.collectionId = uid;
        self.collectionName = name;
        self.collectionPrice = price;
        self.collectionViewUrl = url;
        self.imageUrl = image;
    }

    return self;
}



@end
