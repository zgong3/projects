//
//  Track.swift
//  ItunesObjC729
//
//  Created by mac on 9/12/19.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation


@objcMembers class Track: NSObject {
    
    let artistName: String
    let trackName: String
    let trackPrice: Double
    let trackTimeMillis: Int
    let releaseDate: String
    
    init?(from dict: [String:Any]) {
        
        guard let name = dict["artistName"] as? String,
            let trackName = dict["trackName"] as? String,
            let trackPrice = dict["trackPrice"] as? Double,
            let trackTimeMillis = dict["trackTimeMillis"] as? Int,
            let releaseDate = dict["releaseDate"] as? String else { return nil }
        
        
        self.artistName = name
        self.trackName = trackName
        self.trackPrice = trackPrice
        self.trackTimeMillis = trackTimeMillis
        self.releaseDate = releaseDate
        
    }
    
}
