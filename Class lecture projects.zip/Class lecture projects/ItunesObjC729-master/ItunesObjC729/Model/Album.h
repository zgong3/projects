//
//  Album.h
//  ItunesObjC729
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Album : NSObject

@property (strong, nonatomic) NSString * artistName;
@property (strong, nonatomic) NSNumber * collectionId;
@property (strong, nonatomic) NSString * collectionName;
@property (assign, nonatomic) double collectionPrice;
@property (strong, nonatomic) NSString * collectionViewUrl;
@property (strong, nonatomic) NSString * imageUrl;

-(id)initWithDict:(NSDictionary*) dict;

@end

NS_ASSUME_NONNULL_END
