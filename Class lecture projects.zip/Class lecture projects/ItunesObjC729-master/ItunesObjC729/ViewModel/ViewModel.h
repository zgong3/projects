//
//  ViewModel.h
//  ItunesObjC729
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Album.h"
#import "ViewModelDelegate.h"
@class Track;

NS_ASSUME_NONNULL_BEGIN

@interface ViewModel : NSObject
//create a property: 1. @property, 2. weak or strong, 3. nonatomic or atomic, 4. object type, 5. object name
@property (strong, nonatomic) NSMutableArray<Album*>* albums;
@property (strong, nonatomic) NSMutableArray<Track*>* tracks;

@property (weak, nonatomic) id<ViewModelDelegate> delegate; //weak var delegate: ViewModelDelegate?
-(void)getFrom:(NSString*) search;
-(void)getTracksFor:(Album*)album;

@end

NS_ASSUME_NONNULL_END
