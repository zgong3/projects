//
//  ViewModel.m
//  ItunesObjC729
//
//  Created by mac on 9/9/19.
//  Copyright © 2019 mac. All rights reserved.
//

#import "ViewModel.h"
#import "ItunesService.h"
@implementation ViewModel

- (void)getFrom:(NSString *)search {
    
    [ItunesService.sharedInstance getAlbumsFor:search completion:^(NSMutableArray<Album *> * _Nonnull albums) {
        __weak ViewModel * weakSelf = self;
        weakSelf.albums = albums;
        [weakSelf.delegate updateView];
        NSLog(@"Album Count: %ld", albums.count); //print statement, different data structures have different string interpolation values
    }];
    
}

- (void)getTracksFor:(Album *)album {
    
    [ItunesService.sharedInstance getTracksFor:album completion:^(NSMutableArray<Track *> * _Nonnull tracks) {
        __weak ViewModel * weakSelf = self;
        weakSelf.tracks = tracks;
        [NSNotificationCenter.defaultCenter postNotificationName:@"Album" object:nil];
        NSLog(@"Track Count: %ld", tracks.count);
    }];
}

@end
